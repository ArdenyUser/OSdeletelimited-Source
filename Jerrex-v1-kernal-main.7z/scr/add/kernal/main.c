#include "print.h"

void kernal_main {
    print_clear();
    print_set_color(PRINT_COLOR_YELLOW, PRINT_COLOR_BLACK);
    print_str("ArdenWARE presents Jerrex Kernal");
} 
