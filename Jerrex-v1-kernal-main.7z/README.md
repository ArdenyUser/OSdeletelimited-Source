# ArdenWARE BUILD

First, run docker onto Buildenv and use this command:

*docker build buildenv -t ardenware-buildenv*

Next, run the enviroment:

*docker run --rm -it -v %cd%:/root/env ardenware-buildenv* (WINDOWS)

*docker run --rm -it -v $(pwd):/root/env ardenware-buildenv* (MACOS or LINUX)
